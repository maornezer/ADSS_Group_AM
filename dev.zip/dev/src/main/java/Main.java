import Presentation.MainMenu;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;

public class Main {
    public static void main(String[] args){
        createDB();
        MainMenu mainMenu = new MainMenu();
        mainMenu.printMain();

    }

    private static boolean createDB() {
        // if directory does not exist, create it
        File directory = new File("src/");
        if (!directory.exists())
            directory.mkdir();
        directory = new File("src/resources/");
        if (!directory.exists())
            directory.mkdir();

        String dbPath = "src/resources/identifier.sqlite";
        File dbFile = new File(dbPath);
        if (!dbFile.exists()) {
            try (InputStream in = Main.class.getResourceAsStream("/identifier.sqlite");
                 OutputStream out = new FileOutputStream(dbPath)) {
                byte[] buffer = new byte[1024];
                int length;
                while ((length = in.read(buffer)) > 0) {
                    out.write(buffer, 0, length);
                }
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return true;
    }

}